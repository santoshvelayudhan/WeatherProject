export const BZM_DOMAIN_NET = 'blazemeter.net';
export const BZM_DOMAIN_COM = 'blazemeter.com';
