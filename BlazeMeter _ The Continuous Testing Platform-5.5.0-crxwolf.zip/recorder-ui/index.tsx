import React from 'react';
import ReactDOM from 'react-dom';
import RecorderUi from './recorder-ui';

ReactDOM.render(<RecorderUi />, document.getElementById('recorder-ui'));
