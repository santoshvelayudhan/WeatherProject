import React from 'react';
import ReactDOM from 'react-dom';
import Options from './options';

import './styles/index.scss';

ReactDOM.render(<Options />, document.getElementById('options'));
